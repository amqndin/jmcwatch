# Automatically Compile Your JMC Code on Save!

## Why?
Wingedseal, the CEO of JMC, has refused to implement this feature. So, I thought, "Why not?"

![Proof](images/proof.png)

## How?
Simply use the `jmcwatch` command while your terminal is in your JMC project directory. Every time you save any of your .jmc files, it will automatically run `jmc compile`.

## Contact Me
- Discord: @amandin
- Telegram: @amwndin
